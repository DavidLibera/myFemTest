// CH_ATTRIB_FACENODE.cpp: implementation of the CCH_ATTRIB_FACENODE class.
//
//////////////////////////////////////////////////////////////////////

#include "CH_ATTRIB_FACENODE.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCH_ATTRIB_FACENODE::CCH_ATTRIB_FACENODE()
{
	CCH_ATTRIB_NODE::CCH_ATTRIB_NODE();

	trglFace=NULL;	u=0.0;	v=0.0;	w=0.0;

	flags[0]=TRUE;
}

CCH_ATTRIB_FACENODE::~CCH_ATTRIB_FACENODE()
{
	CCH_ATTRIB_NODE::~CCH_ATTRIB_NODE();
}
